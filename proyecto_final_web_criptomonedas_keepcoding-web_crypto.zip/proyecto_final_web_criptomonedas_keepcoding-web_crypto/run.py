#punto de entrada al servidor, aquí la aplicación flask aún no existe
from cryptoding_app import app

if __name__ == "__main__":
    app.run()



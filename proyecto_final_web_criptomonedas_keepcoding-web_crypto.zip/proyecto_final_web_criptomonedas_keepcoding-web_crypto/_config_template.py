SECRET_KEY = "tu clave wtf"#conseguir clave en https://randomkeygen.com/ por ejemplo.
BASE_DATOS = "tu base de datos"